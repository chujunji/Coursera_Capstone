# Segmenting-and-Clustering-Neighborhoods-in-Toronto
Coursera IBM Certified course - Segmenting and Clustering Neighborhoods in Toronto solution notebooks
